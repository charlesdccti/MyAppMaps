package br.com.ufba.security.dao;

import br.com.ufba.security.model.Academia;
import br.com.ufba.security.model.Cidade;

public interface IDAOCidade {

	/**
	 * Recupera o registro de Usuário com matrícula e password indicados.
	 * @param matricula
	 * @param password
	 * @return Usuario
	 * 
	 * @author 
	 * @return 
	 */
	//public Usuario findUser(String matricula, String password);
	
	/**
	 * Salva um cidade no banco.
	 * 
	 * @param cidade
	 * @return
	 * 		
	 * @author 
	 */
	public Cidade salvarCidade(Cidade cidade);
}
