/**
 * 
 */
package br.com.ufba.security.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;



/**
 * Created by charles on 18/05/2016.
 */
@Entity
@Table(name = "endereco")
public class Endereco implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7764313345212576070L;
	
	@Id
	@GeneratedValue
	private Integer pkEndereco;
    private String bairro;
    private String cep;
    private String rua;   
    private Integer numero;
    private String complemento;
    
    //private Integer fkCidade;
	@OneToOne(fetch = FetchType.LAZY, targetEntity = Cidade.class)
	@JoinColumn(name = "fkCidade")
	private Cidade cidade;

	public Integer getPkEndereco() {
		return pkEndereco;
	}

	public void setPkEndereco(Integer pkEndereco) {
		this.pkEndereco = pkEndereco;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public String getRua() {
		return rua;
	}

	public void setRua(String rua) {
		this.rua = rua;
	}

	public Integer getNumero() {
		return numero;
	}

	public void setNumero(Integer numero) {
		this.numero = numero;
	}

	public String getComplemento() {
		return complemento;
	}

	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}

	public Cidade getCidade() {
		return cidade;
	}

	public void setCidade(Cidade cidade) {
		this.cidade = cidade;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}

    
    
}
