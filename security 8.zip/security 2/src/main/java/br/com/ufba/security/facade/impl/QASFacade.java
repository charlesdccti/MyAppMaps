package br.com.ufba.security.facade.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import br.com.ufba.security.facade.IQASFacade;
import br.com.ufba.security.model.Academia;
//import br.com.ufba.security.model.Usuario;
import br.com.ufba.security.rn.AcademiaRN;
//import br.com.ufba.security.rn.UsuarioRN;

@Service("qasFacade")
public class QASFacade implements IQASFacade {
//	private UsuarioRN usuarioRN;
	private AcademiaRN academiaRN;
	
	@Autowired
	public QASFacade(
//			@Qualifier("usuarioRN") final UsuarioRN usuarioRN, 
			@Qualifier("academiaRN") AcademiaRN academiaRN){
//		this.usuarioRN = usuarioRN;
		this.academiaRN = academiaRN;
	}
	
//	@Override
//	@Transactional(readOnly = true, propagation = Propagation.REQUIRED, rollbackFor = Exception.class, isolation = Isolation.DEFAULT)
//	public Usuario findUser(String matricula, String password) {
//		return usuarioRN.findUser(matricula, password);
//	}
//	
//	@Override
//	@Transactional(readOnly = true, propagation = Propagation.REQUIRED, rollbackFor = Exception.class, isolation = Isolation.DEFAULT)
//	public Usuario findUser(String matricula) {
//		return usuarioRN.findUser(matricula);
//	}
//	
//	@Override
//	@Transactional(readOnly = false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class, isolation = Isolation.DEFAULT)
//	public Usuario bloquearUsuario(Usuario usuario, Integer motivoBloqueio) {
//		return usuarioRN.bloquearUsuario(usuario, motivoBloqueio);
//	}
//	
//	@Override
//	@Transactional(readOnly = true, propagation = Propagation.REQUIRED, rollbackFor = Exception.class, isolation = Isolation.DEFAULT)
//	public Usuario getUsuarioLogado(){
//		return usuarioRN.getUsuarioLogado();
//	}
	
	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class, isolation = Isolation.DEFAULT)
	public Academia salvarAcademia(Academia academia) {
		return academiaRN.salvarAcademia(academia);
	}
}