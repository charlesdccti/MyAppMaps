package br.com.ufba.security.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * Created by charles on 18/05/2016.
 */
@Entity
@Table(name = "academia")
public class Academia implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = -9076461224643583037L;
	
	@Id
	@GeneratedValue
	private Integer pkAcademia;
    private String nome;
    private String celular;   
    private boolean isSede;
    private double lat;
    private double lng;
    
    //private Integer fkCidade;
	@OneToOne(fetch = FetchType.LAZY, targetEntity = Endereco.class)
	@JoinColumn(name = "fkEndereco")
	private Endereco endereco;

	public Integer getPkAcademia() {
		return pkAcademia;
	}

	public void setPkAcademia(Integer pkAcademia) {
		this.pkAcademia = pkAcademia;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCelular() {
		return celular;
	}

	public void setCelular(String celular) {
		this.celular = celular;
	}

	public boolean isSede() {
		return isSede;
	}

	public void setSede(boolean isSede) {
		this.isSede = isSede;
	}

	public double getLat() {
		return lat;
	}

	public void setLat(double lat) {
		this.lat = lat;
	}

	public double getLng() {
		return lng;
	}

	public void setLng(double lng) {
		this.lng = lng;
	}

	public Endereco getEndereco() {
		return endereco;
	}

	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}


}
