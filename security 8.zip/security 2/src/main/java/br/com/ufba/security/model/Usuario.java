//package br.com.ufba.security.model;
//
//import java.util.Date;
//
//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
//import javax.persistence.Id;
//import javax.persistence.JoinColumn;
//import javax.persistence.OneToOne;
//import javax.persistence.SequenceGenerator;
//import javax.persistence.Table;
//import javax.persistence.Transient;
//
//@Entity
//@Table(name = "s_usuario")
//public class Usuario {
//
//	@Id
//	@SequenceGenerator(name = "usuarioGenerator", sequenceName = "seq_s_usuario", allocationSize = 1, initialValue = 1)
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "usuarioGenerator")
//	private Integer pkUsuario;
//
//	@OneToOne
//	@JoinColumn(name = "fkservidor")
//	private Servidor servidor;
//	
//	@OneToOne
//	@JoinColumn(name = "fkgrupo")
//	private Grupo grupo;
//
//	@Column(name = "senha")
//	private String senha;
//
//	@Column(name = "alterarsenha")
//	private boolean alterarSenha;
//	
//	@Column(name = "errologin")
//	private Integer erroLogin;
//	
//	@Column(name = "bloqueado")
//	private boolean bloqueado;
//
//	@Column(name = "datainicio")
//	private Date dataInicio;
//
//	@Column(name = "ativo")
//	private boolean ativo;
//	
//	@Column(name = "descricao")
//	private String descricao;
//	
//	@Column(name = "motivobloqueio")
//	private Integer motivoBloqueio;
//	
//	@Transient
//	private String ip;
//
//
//	public String getAtivoStr() {
//		if (this.ativo) {
//			return "Ativo";
//		}
//		return "Inativo";
//	}
//
//	@Override
//	public boolean equals(Object obj) {
//		if (super.equals(obj)) {
//			return true;
//		}
//		if (obj == null)
//			return false;
//
//		if (getClass() != obj.getClass())
//			return false;
//		Usuario usuario = (Usuario) obj;
//		if (this.pkUsuario != null
//				&& this.getPkUsuario().equals(usuario.getPkUsuario()))
//			return true;
//
//		return super.equals(obj);
//	}
//
//	public Integer getPkUsuario() {
//		return pkUsuario;
//	}
//
//	public void setPkUsuario(Integer pkUsuario) {
//		this.pkUsuario = pkUsuario;
//	}
//
//	public Servidor getServidor() {
//		return servidor;
//	}
//
//	public void setServidor(Servidor servidor) {
//		this.servidor = servidor;
//	}
//
//	public Grupo getGrupo() {
//		return grupo;
//	}
//
//	public void setGrupo(Grupo grupo) {
//		this.grupo = grupo;
//	}
//
//	public String getSenha() {
//		return senha;
//	}
//
//	public void setSenha(String senha) {
//		this.senha = senha;
//	}
//
//	public boolean isAlterarSenha() {
//		return alterarSenha;
//	}
//
//	public void setAlterarSenha(boolean alterarSenha) {
//		this.alterarSenha = alterarSenha;
//	}
//
//	public Integer getErroLogin() {
//		return erroLogin;
//	}
//
//	public void setErroLogin(Integer erroLogin) {
//		this.erroLogin = erroLogin;
//	}
//
//	public boolean isBloqueado() {
//		return bloqueado;
//	}
//
//	public void setBloqueado(boolean bloqueado) {
//		this.bloqueado = bloqueado;
//	}
//
//	public Date getDataInicio() {
//		return dataInicio;
//	}
//
//	public void setDataInicio(Date dataInicio) {
//		this.dataInicio = dataInicio;
//	}
//
//	public boolean isAtivo() {
//		return ativo;
//	}
//
//	public void setAtivo(boolean ativo) {
//		this.ativo = ativo;
//	}
//
//	public String getDescricao() {
//		return descricao;
//	}
//
//	public void setDescricao(String descricao) {
//		this.descricao = descricao;
//	}
//
//	public Integer isMotivoBloqueio() {
//		return motivoBloqueio;
//	}
//
//	public void setMotivoBloqueio(Integer motivoBloqueio) {
//		this.motivoBloqueio = motivoBloqueio;
//	}
//
//	public String getIp() {
//		return ip;
//	}
//
//	public void setIp(String ip) {
//		this.ip = ip;
//	}
//	
//}
