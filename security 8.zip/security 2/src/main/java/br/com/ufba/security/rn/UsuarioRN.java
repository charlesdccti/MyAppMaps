//package br.com.ufba.security.rn;
//
//import java.io.Serializable;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import br.com.ufba.security.dao.IDAOUsuario;
//import br.com.ufba.security.model.Usuario;
//
//@Service("usuarioRN")
//public class UsuarioRN implements Serializable {
//	@Autowired
//	private IDAOUsuario usuarioDAO;
//	
//	public static final Integer MOTIVO_BLOQUEIO_TRES_TENTATIVAS_ERRO_LOGIN = new Integer(0);  
//	public IDAOUsuario getUsuarioDAO() {
//		return usuarioDAO;
//	}
//
//	public void setUsuarioDAO(IDAOUsuario usuarioDAO) {
//		this.usuarioDAO = usuarioDAO;
//	}
//
//	/**
//	 * Recupera o registro de Usuário com matrícula e password indicados.
//	 * @param matricula
//	 * @param password
//	 * @return Usuario
//	 * 
//	 * @author 
//	 */
//	public Usuario findUser(String matricula, String password){
//		return usuarioDAO.findUser(matricula, password);
//	}
//
//	/**
//	 * Recuperar o registro de Usuário com a matrícula indicada
//	 * @param matricula
//	 * @return Usuario
//	 * 
//	 * @author 
//	 */
//	public Usuario findUser(String matricula) {
//		return usuarioDAO.findUser(matricula);
//	}
//
//	/**
//	 * Bloqueia o Usuário com a matricula em questão 
//	 * @param usuario
//	 * @param motivoBloqueio
//	 * @return Usuario
//	 * 
//	 * @author 
//	 */
//	public Usuario bloquearUsuario(Usuario usuario, Integer motivoBloqueio){
//		return usuarioDAO.bloquearUsuario(usuario, motivoBloqueio);
//	}
//	
//	/**
//	 * Recupera a entidade Usuário do usuário logado na sessão
//	 * @return Usuario
//	 */
//	public Usuario getUsuarioLogado(){
//		return usuarioDAO.getUsuarioLogado();
//	}
//}
