//package br.com.ufba.security.dao;
//
//import br.com.ufba.security.model.Atendimento;
//
//public interface IDAOAtendimento {
//
//	/**
//	 * Recupera o registro de Usuário com matrícula e password indicados.
//	 * @param matricula
//	 * @param password
//	 * @return Usuario
//	 * 
//	 * @author 
//	 * @return 
//	 */
//	//public Usuario findUser(String matricula, String password);
//	
//	/**
//	 * Salva um atendimento no banco.
//	 * 
//	 * @param atendimento
//	 * @return
//	 * 
//	 * @author 
//	 */
//	public Atendimento salvarAtendimento(Atendimento atendimento);
//}
