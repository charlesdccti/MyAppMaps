package br.com.ufba.security.facade;

import br.com.ufba.security.model.Academia;
//import br.com.ufba.security.model.Usuario;


public interface IQASFacade {
	
//	/**
//	 * Recupera o registro de Usuário com matrícula e password indicados.
//	 * @param matricula
//	 * @param password
//	 * @return Usuario
//	 * 
//	 * @author 
//	 */
//	public Usuario findUser(String matricula, String password);
//
//	/**
//	 * Recuperar o registro de Usuário com a matrícula indicada
//	 * @param matricula
//	 * @return Usuario
//	 * 
//	 * @author 
//	 */
//	public Usuario findUser(String matricula);
//
//	/**
//	 * Bloqueia o Usuário com a matricula em questão 
//	 * @param usuario
//	 * @param motivoBloqueio
//	 * @return Usuario
//	 * 
//	 * @author 
//	 */
//	public Usuario bloquearUsuario(Usuario usuario, Integer motivoBloqueio);
//
//	/**
//	 * Recupera a entidade Usuário do usuário logado na sessão
//	 * @return Usuario
//	 */
//	public Usuario getUsuarioLogado();

	/**
	 * Salva academias no banco.
	 * 
	 * @param academia
	 * @return academia
	 * 
	 * @author charles
	 */
	public Academia salvarAcademia(Academia academia);
}
