//package br.com.ufba.security.bean;
//
//import java.io.IOException;
//import java.util.ArrayList;
//import java.util.List;
//
//import javax.enterprise.context.SessionScoped;
//import javax.faces.application.FacesMessage;
//import javax.faces.bean.ManagedBean;
//import javax.faces.bean.ManagedProperty;
//import javax.faces.bean.ViewScoped;
//import javax.faces.context.ExternalContext;
//import javax.faces.context.FacesContext;
//import javax.servlet.http.HttpSession;
//
//import org.primefaces.context.RequestContext;
//import org.springframework.security.authentication.AuthenticationManager;
//import org.springframework.security.authentication.BadCredentialsException;
//import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
//import org.springframework.security.core.Authentication;
//import org.springframework.security.core.context.SecurityContextHolder;
//import org.springframework.security.web.WebAttributes;
//import org.springframework.security.web.savedrequest.DefaultSavedRequest;
//
//import br.com.ufba.security.model.Atendimento;
//import br.com.ufba.security.model.Usuario;
//import br.com.ufba.security.rn.UsuarioRN;
//import br.com.ufba.security.util.FacesUtils;
//import br.com.ufba.security.util.Util;
//
//@ManagedBean(name = "atendimentoBean")
//@ViewScoped
//public class AtendimentoBean extends BaseBean{
//	private Atendimento atendimento;
//	private List<Atendimento> atendimentoList;
//	private Usuario usuarioLogado;	
//
//	
//	
//	public AtendimentoBean() {
//		this.atendimento = new Atendimento();
//		this.atendimentoList = new ArrayList<Atendimento>();
//	}
//
//	public Atendimento getAtendimento() {
//		return atendimento;
//	}
//
//	public void setAtendimento(Atendimento atendimento) {
//		this.atendimento = atendimento;
//	}
//
//	public List<Atendimento> getAtendimentoList() {
//		return atendimentoList;
//	}
//
//	public void setAtendimentoList(List<Atendimento> atendimentoList) {
//		this.atendimentoList = atendimentoList;
//	}
//
//	public Usuario getUsuarioLogado() {
//		return usuarioLogado;
//	}
//
//	public void setUsuarioLogado(Usuario usuarioLogado) {
//		this.usuarioLogado = usuarioLogado;
//	}
//	
//	public Atendimento inserir() {
//		
//		this.usuarioLogado = this.getQasFacade().getUsuarioLogado();
//		//		this.atendimento.setUsuario(this.usuarioLogado);
//		//		this.atendimento.setAtivo(true);
//				
//		atendimento = this.getQasFacade().salvarAtendimento(this.atendimento);	
//		return atendimento;
//	}
//	
//}