//package br.com.ufba.security.bean;
//
//import java.io.IOException;
//
//import javax.enterprise.context.SessionScoped;
//import javax.faces.application.FacesMessage;
//import javax.faces.bean.ManagedBean;
//import javax.faces.bean.ManagedProperty;
//import javax.faces.context.ExternalContext;
//import javax.faces.context.FacesContext;
//import javax.servlet.http.HttpSession;
//
//import org.primefaces.context.RequestContext;
//import org.springframework.security.authentication.AuthenticationManager;
//import org.springframework.security.authentication.BadCredentialsException;
//import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
//import org.springframework.security.core.Authentication;
//import org.springframework.security.core.context.SecurityContextHolder;
//import org.springframework.security.web.WebAttributes;
//import org.springframework.security.web.savedrequest.DefaultSavedRequest;
//
//import br.com.ufba.security.model.Usuario;
//import br.com.ufba.security.rn.UsuarioRN;
//import br.com.ufba.security.util.FacesUtils;
//import br.com.ufba.security.util.Util;
//
//@ManagedBean(name = "loginBean")
//@SessionScoped
//public class LoginBean extends BaseBean{
//	private String matricula;
//	private String password;
//	private Usuario usuarioLogado;
//	
//	private Integer qtdTentativasLogin = 0;
//	@ManagedProperty("#{authenticationManager}")
//	private AuthenticationManager authenticationManager;
//
//	public LoginBean() {	
//		this.matricula = "";
//		this.password = "";
//	}
//	
//	public AuthenticationManager getAuthenticationManager() {
//		return authenticationManager;
//	}
//
//	public void setAuthenticationManager(AuthenticationManager authenticationManager) {
//		this.authenticationManager = authenticationManager;
//	}
//	
//	public String getMatricula() {
//		return matricula;
//	}
//	
//	public void setMatricula(String matricula) {
//		this.matricula = matricula;
//	}
//	
//	public String getPassword() {
//		return password;
//	}
//	
//	public void setPassword(String password) {
//		this.password = password;
//	}
//	
//	public Usuario getUsuarioLogado() {
//		return usuarioLogado;
//	}
//
//	public void setUsuarioLogado(Usuario usuarioLogado) {
//		this.usuarioLogado = usuarioLogado;
//	}
//
//	public void getLogin(){
//		FacesMessage facesMsg;
//		try {
//			Authentication request = new UsernamePasswordAuthenticationToken(this.matricula, this.password);
//			Authentication result = authenticationManager.authenticate(request);
//			SecurityContextHolder.getContext().setAuthentication(result);
//			
//			//return "/security/restrito/principal.xhtml?faces-redirect=true";
//
//			FacesContext.getCurrentInstance().getExternalContext().redirect("/security/restrito/principal.xhtml");
//
////			System.out.println("Usuario autentidado? "+ result.isAuthenticated());
////			usuarioLogado = new Usuario();
////			usuarioLogado.setAtivo(true);
////			usuarioLogado.setAlterarSenha(false);
////			if(result.isAuthenticated()){
////				
////				usuarioLogado  = super.getSrhFacade().findUser(this.matricula, this.password);
////				if(!Util.isEmptyOrNull(usuarioLogado)){
////					if (!this.usuarioLogado.isAtivo()) {
////						facesMsg = new FacesMessage(
////								FacesMessage.SEVERITY_FATAL, "Erro de Acesso",
////								"Usuário inativo.");
////						RequestContext.getCurrentInstance()
////								.showMessageInDialog(facesMsg);
////						return null;
////					}
////			
////					if (this.usuarioLogado.isAlterarSenha())
////						return "/restrito/login/alterarSenha.xhtml?faces-redirect=true";
////				}
////			}
//		} catch (BadCredentialsException e) {
//			Usuario usuario = this.getQasFacade().findUser(this.matricula);
//			if(!Util.isEmptyOrNull(usuario)){
//				qtdTentativasLogin++;
//				if (qtdTentativasLogin > 3) {
//					facesMsg = new FacesMessage(FacesMessage.SEVERITY_FATAL,
//							"Erro de Acesso",
//							"Matricula bloqueado por exceder o número de tentativas.");
//					RequestContext.getCurrentInstance().showMessageInDialog(facesMsg);
//					if(!Util.isEmptyOrNull(usuario)){
//						usuario = this.getQasFacade().bloquearUsuario(usuario, UsuarioRN.MOTIVO_BLOQUEIO_TRES_TENTATIVAS_ERRO_LOGIN);
//					}
//				} else {
//					facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR,
//							"Erro de Acesso", "Matricula ou Senha inválidos.");
//					RequestContext.getCurrentInstance().showMessageInDialog(facesMsg);
//				}
//			}
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//
////			return null;
////		}
////		
////		if (!Util.isEmptyOrNull(AplicacaoBean.getSessionMap().get(usuarioLogado.getPkUsuario()))) {
////			RequestContext.getCurrentInstance().execute(
////					"PF('confirmacao').show()");
////		} else {
////			this.verificarAcessoAoSistema();
////		}
////		return "";
////		
//	}
//	
//	public String verificarAcessoAoSistema(){
//		if(Util.isEmptyOrNull(usuarioLogado))
//			usuarioLogado = this.getQasFacade().getUsuarioLogado();
//		
//		if (!Util.isEmptyOrNull(AplicacaoBean.getSessionMap().get(
//				usuarioLogado.getPkUsuario()))) {
//				HttpSession sessao = (HttpSession) AplicacaoBean.getSessionMap().get(usuarioLogado.getPkUsuario());
//			try{
//					sessao.invalidate();
//			} catch (Exception e) {
//				AplicacaoBean.getSessionMap().remove(
//						usuarioLogado.getPkUsuario());
//			}
//		}
//		HttpSession session = (HttpSession) FacesContext.getCurrentInstance()
//				.getExternalContext().getSession(true);
//		AplicacaoBean.getSessionMap().put(usuarioLogado.getPkUsuario(), session);
//		
//		ExternalContext contextoExterno = FacesContext.getCurrentInstance()
//				.getExternalContext();
//		DefaultSavedRequest requisicaoSalva = (DefaultSavedRequest) contextoExterno
//				.getSessionMap().get(WebAttributes.SAVED_REQUEST);
//		
//		try {
//			if (requisicaoSalva != null) {
//				contextoExterno.redirect(requisicaoSalva.getRedirectUrl());
//			} else {
//				FacesContext.getCurrentInstance().getExternalContext().redirect("/security/restrito/principal.xhtml");
//			}
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//		
//		return "";
//	}
//	
//	public void logout(){
//		try {
////			if(Util.isEmptyOrNull(usuarioLogado))
////				usuarioLogado = this.getSrhFacade().getUsuarioLogado();
////			
////			HttpSession sessao = (HttpSession) AplicacaoBean.getSessionMap().get(usuarioLogado.getPkUsuario());
////			try{
////					sessao.invalidate();
////			} catch (Exception e) {
////				AplicacaoBean.getSessionMap().remove(
////						usuarioLogado.getPkUsuario());
////			}
////			AplicacaoBean.getSessionMap().remove(
////					usuarioLogado.getPkUsuario());
//			//facesContext.getCurrentInstance().getExternalContext().getSession(false);
//			//FacesContext.getCurrentInstance().getExternalContext().getSessionMap().remove()
//
//			FacesContext.getCurrentInstance().getExternalContext().redirect("/security/publico/login.xhtml");
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//	}
//}