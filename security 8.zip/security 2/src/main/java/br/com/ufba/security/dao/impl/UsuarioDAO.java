//package br.com.ufba.security.dao.impl;
//
//import java.io.Serializable;
//
//import javax.faces.context.ExternalContext;
//import javax.faces.context.FacesContext;
//import javax.persistence.NoResultException;
//import javax.persistence.Query;
//
//import org.springframework.stereotype.Repository;
//import org.springframework.transaction.annotation.Isolation;
//import org.springframework.transaction.annotation.Propagation;
//import org.springframework.transaction.annotation.Transactional;
//
//import br.com.ufba.security.dao.AbstractJpaDAO;
//import br.com.ufba.security.dao.IDAOUsuario;
//import br.com.ufba.security.model.Usuario;
//
//@Repository("usuarioDAO")
//public class UsuarioDAO extends AbstractJpaDAO<Usuario, Integer> implements IDAOUsuario, Serializable{
//
//	@Override
//	public Usuario findUser(String matricula, String password) {
//		Usuario usuario;
//		try {
//			String jpql = "SELECT u FROM Usuario u WHERE u.servidor.matricula=:pMatricula AND u.senha LIKE :pPassword";
//			
//			Query query = this.getEntityManager().createQuery(jpql);
//			
//			query.setParameter("pMatricula", matricula);
//			query.setParameter("pPassword", password);
//			
//			usuario = (Usuario) query.getSingleResult();
//		} catch (NoResultException e) {
//			System.err.println("Nenhum usuário foi encontrado com esta matrícula e senha");
//			usuario = null;
//		}
//
//		return usuario;
//	}
//
//	@Override
//	public Usuario findUser(String matricula) {
//		Usuario usuario;
//		try {
//			String jpql = "SELECT u FROM Usuario u WHERE u.servidor.matricula=:pMatricula";
//			
//			Query query = this.getEntityManager().createQuery(jpql);
//			
//			query.setParameter("pMatricula", matricula);
//			
//			usuario = (Usuario) query.getSingleResult();
//		} catch (NoResultException e) {
//			System.err.println("Nenhum usuário foi encontrado com a matrícula: "+matricula);
//			usuario = null;
//		}
//
//		return usuario;
//	}
//	
//	@Override
//	public Usuario bloquearUsuario(Usuario usuario, Integer motivoBloqueio) {
//		usuario.setMotivoBloqueio(motivoBloqueio);
//		usuario.setBloqueado(true);
//		
//		usuario = super.update(usuario);
//
//		return usuario;
//	}
//
//	@Override
//	@Transactional(propagation = Propagation.MANDATORY, isolation = Isolation.DEFAULT)
//	public Usuario getUsuarioLogado() {
//		FacesContext contexto = FacesContext.getCurrentInstance();
//		ExternalContext contextoExterno = contexto.getExternalContext();
//		
//		String matricula = contextoExterno.getRemoteUser();
//		
//		String jpql = "SELECT u FROM Usuario u WHERE u.servidor.matricula=:pMatricula";
//		Query query = this.getEntityManager().createQuery(jpql);
//		
//		query.setParameter("pMatricula", matricula);
//		
//		Usuario usuario = (Usuario) query.getSingleResult();
//		
//		return usuario;
//	}
//}
