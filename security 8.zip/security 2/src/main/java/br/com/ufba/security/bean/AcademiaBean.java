package br.com.ufba.security.bean;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

import java.io.Serializable;

import javax.annotation.PostConstruct; 
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
  




import org.primefaces.context.RequestContext;
import org.primefaces.event.map.PointSelectEvent;
import org.primefaces.model.map.DefaultMapModel;
import org.primefaces.model.map.LatLng;
import org.primefaces.model.map.MapModel;
import org.primefaces.model.map.Marker;






import br.com.ufba.security.model.Academia;
import br.com.ufba.security.model.Cidade;
import br.com.ufba.security.model.Endereco;
import br.com.ufba.security.model.Estado;
//import br.com.ufba.security.model.Usuario;
//import br.com.ufba.security.rn.UsuarioRN;
import br.com.ufba.security.util.FacesUtils;
import br.com.ufba.security.util.Util;

@ManagedBean(name = "academiaBean")
@ViewScoped
public class AcademiaBean extends BaseBean{
	private Academia academia = new Academia();
	private Academia academiaRetorno = new Academia();
	private Endereco emdereco = new Endereco();
	private List<Academia> academiaList = new ArrayList<Academia>();
//	private Usuario usuarioLogado;	
	private FacesMessage message;
	private Endereco endereco = new Endereco();
	private Cidade cidade = new Cidade();
	private Estado estado = new Estado();

	
    private MapModel emptyModel;
    
    private String title;
      
    private double lat;
      
    private double lng;
  
    @PostConstruct
    public void init() {
        emptyModel = new DefaultMapModel();
        academia.setEndereco(new Endereco());
        academia.getEndereco().setCidade(new Cidade());
        academia.getEndereco().getCidade().setEstado(new Estado());
    }
      
    public MapModel getEmptyModel() {
        return emptyModel;
    }
      
    public String getTitle() {
        return title;
    }
  
    public void setTitle(String title) {
        this.title = title;
    }
  
    public double getLat() {
        return lat;
    }
  
    public void setLat(double lat) {
        this.lat = lat;
    }
  
    public double getLng() {
        return lng;
    }
  
    public void setLng(double lng) {
        this.lng = lng;
    }
      
    public void addMarker() {
        //Marker marker = new Marker(new LatLng(academia.getLat(), academia.getLng()), academia.getNome());
        Marker marker = new Marker(new LatLng(this.lat, this.lng), academia.getNome());
        emptyModel.addOverlay(marker);
//        academia.setLat(lat);
//        academia.setLng(lng);
        //academia.setNome(); --> já foi setada no dialog
          
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Marker Added", "Lat:" + academia.getLat() + ", Lng:" + academia.getLng()+", Academia:"+academia.getNome()));
    }
    
    public void novo(PointSelectEvent event) {
       //local = new Local();
        LatLng coord = event.getLatLng();
        academia.setLat(coord.getLat());
        academia.setLng(coord.getLng());
        lat = coord.getLat();
        lng = coord.getLng();
        
        Marker marker = new Marker(new LatLng(this.lat, this.lng), "Marcador");
        emptyModel.addOverlay(marker);
    }
	
	
	
	
	public AcademiaBean() {
		//		this.academia = new Academia();
		//		this.academiaList = new ArrayList<Academia>();
	}

	public Academia getAcademia() {
		return academia;
	}

	public void setAcademia(Academia academia) {
		this.academia = academia;
	}

	public List<Academia> getAcademiaList() {
		return academiaList;
	}

	public void setAcademiaList(List<Academia> academiaList) {
		this.academiaList = academiaList;
	}

//	public Usuario getUsuarioLogado() {
//		return usuarioLogado;
//	}
//
//	public void setUsuarioLogado(Usuario usuarioLogado) {
//		this.usuarioLogado = usuarioLogado;
//	}
//	
	public Academia inserir() {
		
		//this.usuarioLogado = this.getQasFacade().getUsuarioLogado();
		//		this.academia.setUsuario(this.usuarioLogado);
		//		this.academia.setAtivo(true);
		
		academia.getEndereco().getCidade().setPkCidade(1);
		academia.getEndereco().setPkEndereco(1);
		academia.getEndereco().getCidade().getEstado().setPkEstado(1);

				
		academia = this.getQasFacade().salvarAcademia(this.academia);
		
		message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Sucesso!!",
				" Academia cadastrada.");
		RequestContext.getCurrentInstance().showMessageInDialog(message);
		
		academiaRetorno = this.academia;
		//limpando o formulário e o mapa
		academia = new Academia();
		emptyModel = new DefaultMapModel(); 
		this.lat = 0;
		this.lng = 0;
		return academiaRetorno;
	}
	
    public void addMessage() {
        String summary = this.academia.isSede() ? "Academia Sede" : "Academia não é Sede";
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(summary));
    }

	public Endereco getEmdereco() {
		return emdereco;
	}

	public void setEmdereco(Endereco emdereco) {
		this.emdereco = emdereco;
	}

	public Endereco getEndereco() {
		return endereco;
	}

	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}

	public Cidade getCidade() {
		return cidade;
	}

	public void setCidade(Cidade cidade) {
		this.cidade = cidade;
	}

	public Estado getEstado() {
		return estado;
	}

	public void setEstado(Estado estado) {
		this.estado = estado;
	}

	public void setEmptyModel(MapModel emptyModel) {
		this.emptyModel = emptyModel;
	}
    
    
    
	
}