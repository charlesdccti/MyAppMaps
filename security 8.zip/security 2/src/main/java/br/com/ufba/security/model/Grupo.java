//package br.com.ufba.security.model;
//
//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
//import javax.persistence.Id;
//import javax.persistence.SequenceGenerator;
//import javax.persistence.Table;
//
//@Entity
//@Table(name = "s_grupo")
//public class Grupo {
//	@Id
//	@SequenceGenerator(name = "grupoGenerator", sequenceName = "seq_s_grupo", allocationSize = 1, initialValue = 1)
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "grupoGenerator")
//	private Integer pkGrupo;
//	
//	@Column(name="nome")
//	private String nome;
//	
//	@Column(name="descricao")
//	private String descricao;
//	
//	@Column(name="permissao")
//	private String permissao;
//	
//	@Column(name="ativo")
//	private boolean ativo;
//
//	public Integer getPkGrupo() {
//		return pkGrupo;
//	}
//
//	public void setPkGrupo(Integer pkGrupo) {
//		this.pkGrupo = pkGrupo;
//	}
//
//	public String getNome() {
//		return nome;
//	}
//
//	public void setNome(String nome) {
//		this.nome = nome;
//	}
//
//	public String getDescricao() {
//		return descricao;
//	}
//
//	public void setDescricao(String descricao) {
//		this.descricao = descricao;
//	}
//
//	public String getPermissao() {
//		return permissao;
//	}
//
//	public void setPermissao(String permissao) {
//		this.permissao = permissao;
//	}
//
//	public boolean isAtivo() {
//		return ativo;
//	}
//
//	public void setAtivo(boolean ativo) {
//		this.ativo = ativo;
//	}
//}
