package br.com.ufba.security.rn;

import java.io.Serializable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.ufba.security.dao.IDAOAcademia;
import br.com.ufba.security.dao.IDAOCidade;
import br.com.ufba.security.dao.IDAOEndereco;
import br.com.ufba.security.dao.IDAOEstado;
import br.com.ufba.security.model.Academia;
import br.com.ufba.security.model.Estado;

@Service("academiaRN")
public class AcademiaRN implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -785233465841993959L;

	@Autowired
	private IDAOAcademia academiaDAO;
	
	@Autowired
	private IDAOEndereco enderecoDAO;
	
	@Autowired
	private IDAOCidade cidadeDAO;
	
	@Autowired
	private IDAOEstado estadoDAO;
	
	public static final Integer MOTIVO_BLOQUEIO_TRES_TENTATIVAS_ERRO_LOGIN = new Integer(0);  

	public IDAOAcademia getAcademiaDAO() {
		return academiaDAO;
	}

	public void setAcademiaDAO(IDAOAcademia academiaDAO) {
		this.academiaDAO = academiaDAO;
	}

	/**
	 * Recupera o registro de Usuário com matrícula e password indicados.
	 * @param matricula
	 * @param password
	 * @return Usuario
	 * 
	 * @author 
	 */
	//	public Usuario findUser(String matricula, String password){
	//		return academiaDAO.findUser(matricula, password);
	//	}
	
	/**
	 * 
	 * @param academia
	 * @return academia
	 */
	public Academia salvarAcademia(Academia academia) {
//		
//		Estado estado = this.estadoDAO.salvarEstado(academia.getEndereco().getCidade().getEstado());
//		academia.getEndereco().getCidade().setEstado(estado);;
//		Cidade cidade = this.cidadeDAO.salvarCidade(academia.getEndereco().getCidade());
//		academia.getEndereco().setCidade(cidade);
//		this.enderecoDAO.salvarEndereco(academia.getEndereco());
//		
//		Estado estado = this.estadoDAO.salvarEstado(academia.getEndereco().getCidade().getEstado());
//		academia.getEndereco().getCidade().setEstado(estado);
//		this.cidadeDAO.salvarCidade(academia.getEndereco().getCidade());
//		academia.getEndereco().getCidade().getEstado()
//		this.enderecoDAO.salvarEndereco(academia.getEndereco());
		
		return this.academiaDAO.salvarAcademia(academia);
	}
}
