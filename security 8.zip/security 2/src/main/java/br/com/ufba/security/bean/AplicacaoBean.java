package br.com.ufba.security.bean;

import java.util.HashMap;

import javax.ejb.Init;
import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;
import javax.servlet.http.HttpSession;

@ApplicationScoped
@ManagedBean
public class AplicacaoBean {
	private static HashMap<Integer,HttpSession> sessionHashMap;
	
	@Init
	public void init(){
		sessionHashMap = new HashMap<Integer, HttpSession>();
	}
	public static HashMap<Integer,HttpSession> getSessionMap(){
		if(sessionHashMap==null){
			sessionHashMap= new HashMap<Integer,HttpSession>();
		}
	
		return sessionHashMap;
	}
}
