package br.com.ufba.security.dao.impl;

import java.io.Serializable;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.persistence.NoResultException;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import br.com.ufba.security.dao.AbstractJpaDAO;
import br.com.ufba.security.dao.IDAOEndereco;
import br.com.ufba.security.model.Endereco;

@Repository("enderecoDAO")
public class EnderecoDAO extends AbstractJpaDAO<Endereco, Integer> implements IDAOEndereco, Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1789029939931301764L;

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class, isolation = Isolation.DEFAULT)
	public Endereco salvarEndereco(Endereco endereco) {
		return this.update(endereco);
	}

	//	@Override
	//	public Usuario findUser(String matricula, String password) {
	//		Usuario usuario;
	//		try {
	//			String jpql = "SELECT u FROM Usuario u WHERE u.servidor.matricula=:pMatricula AND u.senha LIKE :pPassword";
	//			
	//			Query query = this.getEntityManager().createQuery(jpql);
	//			
	//			query.setParameter("pMatricula", matricula);
	//			query.setParameter("pPassword", password);
	//			
	//			usuario = (Usuario) query.getSingleResult();
	//		} catch (NoResultException e) {
	//			System.err.println("Nenhum usuário foi encontrado com esta matrícula e senha");
	//			usuario = null;
	//		}
	//
	//		return usuario;
	//	}


	

}
