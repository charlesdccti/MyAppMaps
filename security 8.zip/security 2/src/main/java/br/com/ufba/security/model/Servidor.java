//package br.com.ufba.security.model;
//
//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
//import javax.persistence.Id;
//import javax.persistence.SequenceGenerator;
//import javax.persistence.Table;
//
//@Entity
//@Table(name = "s_servidor")
//public class Servidor {
//	@Id
//	@SequenceGenerator(name = "servidorGenerator", sequenceName = "seq_s_servidor", allocationSize = 1, initialValue = 1)
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "servidorGenerator")
//	private Integer pkServidor;
//	
//	@Column(name="matricula")
//	private String matricula;
//	
//	@Column(name="nome")
//	private String nome;
//
//	public Integer getPkServidor() {
//		return pkServidor;
//	}
//
//	public void setPkServidor(Integer pkServidor) {
//		this.pkServidor = pkServidor;
//	}
//
//	public String getMatricula() {
//		return matricula;
//	}
//
//	public void setMatricula(String matricula) {
//		this.matricula = matricula;
//	}
//
//	public String getNome() {
//		return nome;
//	}
//
//	public void setNome(String nome) {
//		this.nome = nome;
//	}
//	
//}
