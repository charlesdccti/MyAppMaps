package br.com.ufba.security.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;

public class Util {
	public static boolean isEmptyOrNull(Object o) {
		if (o == null) {
			return true;
		} else {
			if (o instanceof String) {
				String s = (String) o;
				if (s.trim().equals("")) {
					return true;
				}
			}
		}
		return false;
	}

	public static boolean isEmptyOrNull(Collection o) {
		if (o == null) {
			return true;
		} else {
			if (o.size() == 0) {
				return true;
			}
		}
		return false;
	}

	public static String convertDateExtenso(Date date) {
		DateFormat dfmt = new SimpleDateFormat("EEEE, d 'de' MMMM 'de' yyyy");
		return dfmt.format(date);
	}

	public static String generateAleatoryPassword() {
		String[] carct = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
				"a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l",
				"m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x",
				"y", "z", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J",
				"K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V",
				"W", "X", "Y", "Z" };
		String senha = "";

		for (int x = 0; x < 6; x++) {
			int j = (int) (Math.random() * carct.length);
			senha += carct[j];
		}
		return senha;
	}

//	public static void sendMail(Usuario user, String topico, String conteudo) {
//		Properties props = new Properties();
//		props.setProperty("mail.transport.protocol", "smtp");
//		props.setProperty("mail.smtp.host", "envio.ba.gov.br");
//		props.setProperty("mail.smtp.port", "25");
//		props.setProperty("mail.smtp.auth", "true");
//		props.setProperty("mail.smtp.starttls.enable", "true");
//		props.setProperty("mail.mime.charset", "UTF-8");
//
//		Session mailSession = Session.getInstance(props,
//				new javax.mail.Authenticator() {
//					protected PasswordAuthentication getPasswordAuthentication() {
//						return new PasswordAuthentication("srh.ctit",
//								"4RATesf5");
//					}
//				});
//		mailSession.setDebug(true);
//		Transport transport;
//		try {
//			transport = mailSession.getTransport();
//
//			MimeMessage message = new MimeMessage(mailSession);
//			message.setSubject(
//					"SRH - Sistema de Recursos Humanos",
//					"text/html; charset=\"utf-8\"");
//			message.setFrom(new InternetAddress(
//					"SRH - Sistema de Recursos Humanos<srh.ctit@pcivil.ba.gov.br>"));
//
//			// This mail has 2 part, the BODY and the embedded image
//			MimeMultipart multipart = new MimeMultipart("related");
//
//			// first part (the html)
//			BodyPart messageBodyPart = new MimeBodyPart();
//			String htmlText = "<div id=\"div\" align=\"center\" style=\"background:white; border:15px solid; border-color:#4682B4; background-clip: content-box; border-radius:25px; margin-left:20px; width:502px; height:260px\"><div style=\"margin-left:5px; margin-top:5px; margin-bottom:5px;\">"
//					+ "<img id=\"imagem\" height=\"70\" width=\"490\" src=\"cid:image\" border=\"1\" style=\"margin-top:3px;\"/>"
//					+ "<br/>"
//					+ "<h2 style=\"color:#000000\">"
//					+ topico
//					+ "</h2>"
//					+ "<p style=\"color:#000000\">"
//					+ conteudo
//					+ "</p>"
//					+ "<br/><br/>"
//					+ "<p align=\"center\" style=\"font-size:11px; color:#B8B8B8\"><b>CTIT</b> - Coordenação de Tecnologia da Informação e Telecomunicações.<br/>(71) 3116-6452 | (71) 3116-6453</p>"
//					+ "</div></div>";
//			messageBodyPart.setContent(htmlText, "text/html; charset=utf-8");
//			// add it
//			multipart.addBodyPart(messageBodyPart);
//
//			// second part (the image)
//			messageBodyPart = new MimeBodyPart();
//			ExternalContext externalContext = LoginBean.getContext();
//			ServletContext scontext = (ServletContext) externalContext
//					.getContext();
//			DataSource fds = new FileDataSource(
//					scontext.getRealPath("/images/topo_8.jpg"));
//
//			messageBodyPart.setDataHandler(new DataHandler(fds));
//			messageBodyPart.setHeader("Content-ID", "<image>");
//			messageBodyPart.setHeader("Content-Type",
//					"text/html; charset=\"utf-8\"");
//			// add image to the multipart
//			multipart.addBodyPart(messageBodyPart);
//
//			// put everything together
//			message.setContent(multipart, "text/html; charset=utf-8");
//
//			message.addRecipient(Message.RecipientType.TO, new InternetAddress(
//					user.getEmail()));
//
//			transport.connect();
//			transport.sendMessage(message,
//					message.getRecipients(Message.RecipientType.TO));
//			transport.close();
//		} catch (MessagingException e) {
//			e.printStackTrace();
//		}
//	}

	public enum Mes {
		JANEIRO("Janeiro"), FEVEREIRO("Fevereiro"), MARCO("Março"), ABRIL(
				"Abril"), MAIO("Maio"), JUNHO("Junho"), JULHO("Julho"), AGOSTO(
				"Agosto"), SETEMBRO("Setembro"), OUTUBRO("Outubro"), NOVEMBRO(
				"Novembro"), DEZEMBRO("Dezembro");

		private String descricao;

		Mes(String descricao) {
			this.descricao = descricao;
		}

		public String getDescricao() {
			return descricao;
		}
	}

	public enum Dia {
		DOMINGO("Domingo"), SEGUNDA("Segunda"), TERCA("Terca"), QUARTA("Quarta"), QUINTA(
				"Quinta"), SEXTA("Sexta"), SABADO("Sabado");

		private String descricao;

		Dia(String descricao) {
			this.descricao = descricao;
		}

		public String getDescricao() {
			return descricao;
		}
	}
	
	public static String MD5(String md5) {
	   try {
	        java.security.MessageDigest md = java.security.MessageDigest.getInstance("MD5");
	        byte[] array = md.digest(md5.getBytes());
	        StringBuffer sb = new StringBuffer();
	        for (int i = 0; i < array.length; ++i) {
	          sb.append(Integer.toHexString((array[i] & 0xFF) | 0x100).substring(1,3));
	       }
	        return sb.toString();
	    } catch (java.security.NoSuchAlgorithmException e) {
	    	e.printStackTrace();
	    }
	    return null;
	}
}
