package br.com.ufba.security.bean;

import javax.faces.application.FacesMessage;
import javax.faces.application.FacesMessage.Severity;
import javax.faces.bean.ManagedProperty;

import org.primefaces.context.RequestContext;

import br.com.ufba.security.facade.IQASFacade;


public abstract class BaseBean {
	@ManagedProperty("#{qasFacade}")
	private IQASFacade qasFacade;

	protected void addErrorMessage(String componentId, String errorMessage) {
		addMessage(componentId, errorMessage, FacesMessage.SEVERITY_ERROR);
	}

	protected void addErrorMessage(String errorMessage) {
		addErrorMessage(null, errorMessage);
	}

	protected void addInfoMessage(String componentId, String infoMessage) {
		addMessage(componentId, infoMessage, FacesMessage.SEVERITY_INFO);
	}

	protected void addInfoMessage(String infoMessage) {
		addInfoMessage(null, infoMessage);
	}

	private void addMessage(String componentId, String errorMessage,
			Severity severity) {
		FacesMessage message = new FacesMessage(errorMessage);
		message.setSeverity(severity);
		RequestContext.getCurrentInstance().showMessageInDialog(message);
	}

	public IQASFacade getQasFacade() {
		return qasFacade;
	}

	public void setQasFacade(IQASFacade qasFacade) {
		this.qasFacade = qasFacade;
	}



}
