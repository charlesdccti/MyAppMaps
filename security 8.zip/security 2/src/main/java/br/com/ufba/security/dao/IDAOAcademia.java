package br.com.ufba.security.dao;

import br.com.ufba.security.model.Academia;

public interface IDAOAcademia {

	/**
	 * Recupera o registro de Usuário com matrícula e password indicados.
	 * @param matricula
	 * @param password
	 * @return Usuario
	 * 
	 * @author 
	 * @return 
	 */
	//public Usuario findUser(String matricula, String password);
	
	/**
	 * Salva um academia no banco.
	 * 
	 * @param academia
	 * @return
	 * 		
	 * @author 
	 */
	public Academia salvarAcademia(Academia academia);
}
