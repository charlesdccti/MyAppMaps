package br.com.ufba.security.dao;

import br.com.ufba.security.model.Estado;

public interface IDAOEstado {

	/**
	 * Recupera o registro de Usuário com matrícula e password indicados.
	 * @param matricula
	 * @param password
	 * @return Usuario
	 * 
	 * @author 
	 * @return 
	 */
	//public Usuario findUser(String matricula, String password);
	
	/**
	 * Salva um estado no banco.
	 * 
	 * @param estado
	 * @return
	 * 		
	 * @author 
	 */
	public Estado salvarEstado(Estado estado);
}
