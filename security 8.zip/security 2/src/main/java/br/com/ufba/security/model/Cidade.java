/**
 * 
 */
package br.com.ufba.security.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * @author Charles
 *
 */
@Entity
@Table(name = "cidade")
public class Cidade implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2747279202999065515L;
	
	@Id
	@GeneratedValue
	private Integer pkCidade;
	private String nome;
	
	@OneToOne(fetch = FetchType.LAZY, targetEntity = Estado.class)
	@JoinColumn(name = "fkEstado")
	private Estado estado;

	public Integer getPkCidade() {
		return pkCidade;
	}

	public void setPkCidade(Integer pkCidade) {
		this.pkCidade = pkCidade;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Estado getEstado() {
		return estado;
	}

	public void setEstado(Estado estado) {
		this.estado = estado;
	}


	

}
