///**
// * 
// */
//package br.com.ufba.security.model;
//
//import java.util.Date;
//
//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
//import javax.persistence.Id;
//import javax.persistence.JoinColumn;
//import javax.persistence.OneToOne;
//import javax.persistence.SequenceGenerator;
//import javax.persistence.Table;
//import javax.persistence.Transient;
//
///**
// * @author charles
// *
// */
//@Entity
//@Table(name = "atendimento")
//public class Atendimento {
//
//
//	@Id
//	@SequenceGenerator(name = "atendimentoGenerator", sequenceName = "seq_atendimento", allocationSize = 1, initialValue = 1)
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "atendimentoGenerator")
//	private Integer pkatendimento;
//
//	@OneToOne
//	@JoinColumn(name = "fkusuario")
//	private Usuario usuario;
//	
//
//	@Column(name = "titulo")
//	private String titulo;
//
//	@Column(name = "descricao")
//	private String descricao;
//	
//	@Column(name = "data")
//	private Date data;
//	
//	@Column(name = "nota")
//	private Integer nota;
//
//	@Column(name = "atendente")
//	private String atendente;
//	
//	@Column(name = "paciente")
//	private String paciente;
//	
//	@Column(name = "tipo_atendimento")
//	private String tipo_atendimento;
//
//	@Column(name = "ativo")
//	private boolean ativo;
//
//	
//
//	public Integer getPkatendimento() {
//		return pkatendimento;
//	}
//
//	public void setPkatendimento(Integer pkatendimento) {
//		this.pkatendimento = pkatendimento;
//	}
//
//	public Usuario getUsuario() {
//		return usuario;
//	}
//
//	public void setUsuario(Usuario usuario) {
//		this.usuario = usuario;
//	}
//
//	public String getTitulo() {
//		return titulo;
//	}
//
//	public void setTitulo(String titulo) {
//		this.titulo = titulo;
//	}
//
//	public String getDescricao() {
//		return descricao;
//	}
//
//	public void setDescricao(String descricao) {
//		this.descricao = descricao;
//	}
//
//	public Date getData() {
//		return data;
//	}
//
//	public void setData(Date data) {
//		this.data = data;
//	}
//
//	public Integer getNota() {
//		return nota;
//	}
//
//	public void setNota(Integer nota) {
//		this.nota = nota;
//	}
//
//	public String getAtendente() {
//		return atendente;
//	}
//
//	public void setAtendente(String atendente) {
//		this.atendente = atendente;
//	}
//
//	public String getPaciente() {
//		return paciente;
//	}
//
//	public void setPaciente(String paciente) {
//		this.paciente = paciente;
//	}
//
//	public String getTipo_atendimento() {
//		return tipo_atendimento;
//	}
//
//	public void setTipo_atendimento(String tipo_atendimento) {
//		this.tipo_atendimento = tipo_atendimento;
//	}
//
//	public boolean isAtivo() {
//		return ativo;
//	}
//
//	public void setAtivo(boolean ativo) {
//		this.ativo = ativo;
//	}
//
//	
//	
//}
