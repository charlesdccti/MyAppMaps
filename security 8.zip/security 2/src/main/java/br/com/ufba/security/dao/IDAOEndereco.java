package br.com.ufba.security.dao;

import br.com.ufba.security.model.Endereco;

public interface IDAOEndereco {

	/**
	 * Recupera o registro de Usuário com matrícula e password indicados.
	 * @param matricula
	 * @param password
	 * @return Usuario
	 * 
	 * @author 
	 * @return 
	 */
	//public Usuario findUser(String matricula, String password);
	
	/**
	 * Salva um endereco no banco.
	 * 
	 * @param endereco
	 * @return
	 * 		
	 * @author 
	 */
	public Endereco salvarEndereco(Endereco Endereco);
}
