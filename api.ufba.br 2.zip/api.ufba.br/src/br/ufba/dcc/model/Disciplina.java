package br.ufba.dcc.model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Disciplina {

	private String idDisc;

	private String nomeDisc;

	private int credDisc;

	private int horasDisc;

	private int periodo;

	private String obrigOpt;

	
	public Disciplina() {
		super();
	}
	
	public Disciplina(String idDisc, String nomeDisc, int credDisc, int horasDisc, int periodo, String obrigOpt) {
		super();
		this.idDisc = idDisc;
		this.nomeDisc = nomeDisc;
		this.credDisc = credDisc;
		this.horasDisc = horasDisc;
		this.periodo = periodo;
		this.obrigOpt = obrigOpt;
	}

	public int getCredDisc() {
		return credDisc;
	}

	public void setCredDisc(int credDisc) {
		this.credDisc = credDisc;
	}

	public int getHorasDisc() {
		return horasDisc;
	}

	public void setHorasDisc(int horasDisc) {
		this.horasDisc = horasDisc;
	}

	public String getIdDisc() {
		return idDisc;
	}

	public void setIdDisc(String idDisc) {
		this.idDisc = idDisc;
	}

	public String getNomeDisc() {
		return nomeDisc;
	}

	public void setNomeDisc(String nomeDisc) {
		this.nomeDisc = nomeDisc;
	}

	public String getObrigOpt() {
		return obrigOpt;
	}

	public void setObrigOpt(String obrigOpt) {
		this.obrigOpt = obrigOpt;
	}

	public int getPeriodo() {
		return periodo;
	}

	public void setPeriodo(int periodo) {
		this.periodo = periodo;
	}

}

