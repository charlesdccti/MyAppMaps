package br.ufba.dcc.model;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;


/**
 * @author Charles
 *
 */
@XmlRootElement
public class Estado implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1840322489675489636L;

	private Integer pkEstado;
	private String nome;
	
	

	public Integer getPkEstado() {
		return pkEstado;
	}

	public void setPkEstado(Integer pkEstado) {
		this.pkEstado = pkEstado;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	
}
