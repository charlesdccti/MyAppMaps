package br.ufba.dcc.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import br.ufba.dcc.model.Academia;

public enum AcademiaDAO {
	instance;

	private Connection conn;
	private String jdbcURL = "jdbc:mysql://localhost:3306/forro";
	private String nome = "root";
	private String senha = "";

	private AcademiaDAO() {

		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(jdbcURL, nome, senha);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

//	public Academia pegaAcademia(String idDisc) {
//
//		Academia db = new Academia();
//
//		ResultSet rs = null;
//
//		String selectString = "SELECT * FROM academia where iddisc=?";
//
//		try {
//			PreparedStatement selDis = conn.prepareStatement(selectString);
//			selDis.setString(1, idDisc);
//
//			rs = selDis.executeQuery();
//
//			rs.next();
//
//			db.setIdDisc(rs.getString("idDisc"));
//			db.setNomeDisc(rs.getString("nomeDisc"));
//			db.setCredDisc(rs.getInt("credDisc"));
//			db.setHorasDisc(rs.getInt("horasDisc"));
//			db.setPeriodo(rs.getInt("periodo"));
//			db.setObrigOpt(rs.getString("obrigOpt"));
//
//		} catch (SQLException se) {
//			se.printStackTrace();
//		}
//
//		return db;
//	}

//	public String inserirAcademia(Academia disc) {
//
//		String insertString = "insert into academia values(?, ?, ?, ?, ?, ?)";
//	
//		int result = 0;
//		
//		try {
//			PreparedStatement cadDis = conn.prepareStatement(insertString);
//
//			cadDis.setString(1, disc.getIdDisc());
//			cadDis.setString(2, disc.getNomeDisc());
//			cadDis.setInt(3, disc.getCredDisc());
//			cadDis.setInt(4, disc.getHorasDisc());
//			cadDis.setInt(5, disc.getPeriodo());
//			cadDis.setString(6, disc.getObrigOpt());
//			
//			result = cadDis.executeUpdate();
//			
//		} catch (SQLException ex) {
//			System.err.println("SQLException: " + ex.getMessage());
//
//		}
//		
//		if (result==0)
//			return "POST: Academia with id " + disc.getIdDisc() + " not inserted";
//		else
//			return "POST: Academia with id " + disc.getIdDisc() + " was inserted";
//
//	}
//
	public List<Academia> listarAcademias() {

		List<Academia> academias = new ArrayList<Academia>();
		Statement s = null;
		ResultSet rs = null;
		try {
			s = conn.createStatement();
			rs = s.executeQuery("SELECT * FROM academia");
			while (rs.next()) {
				Academia db = new Academia();
				db.setPkAcademia(rs.getInt("pkAcademia"));
				db.setNome(rs.getString("nome"));
				db.setCelular(rs.getString("celular"));
				db.setSede(rs.getBoolean("isSede"));
				db.setLat(rs.getDouble("lat"));
				db.setLng(rs.getDouble("lng"));
				academias.add(db);
			}
		} catch (SQLException se) {
			se.printStackTrace();
		}

		return academias;
	}
//
//	public String apagaAcademia(String idDisc) {
//
//		String selectString = "DELETE FROM academia where iddisc=?";
//		int result = 0;
//		//System.out.println(idDisc);
//		
//		try {
//			PreparedStatement delDis = conn.prepareStatement(selectString);
//			delDis.setString(1, idDisc);
//			result = delDis.executeUpdate();
//		} catch (SQLException se) {
//			se.printStackTrace();
//		}
//		
//		if (result==0)
//			return "DELETE: Academia with id " + idDisc + " not found";
//		else
//			return "DELETE: Academia with id " + idDisc + " was removed";
//	}
//	
//	
//	public List<Academia> listarAcademiasMemoria() {
//
//		List<Academia> academias = new ArrayList<Academia>();
//		
//		Academia academia=  new Academia();
//		academia.setNomeDisc("portugues");
//		academia.setIdDisc("1");
//		academias.add(academia);
//		
//		
//
//		return academias;
//	}
}
