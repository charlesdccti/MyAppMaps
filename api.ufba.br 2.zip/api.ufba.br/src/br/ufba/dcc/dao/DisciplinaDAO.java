package br.ufba.dcc.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import br.ufba.dcc.model.Disciplina;

public enum DisciplinaDAO {
	instance;

	private Connection conn;
	private String jdbcURL = "jdbc:mysql://localhost:3306/forro";
	private String nome = "root";
	private String senha = "";

	private DisciplinaDAO() {

		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(jdbcURL, nome, senha);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public Disciplina pegaDisciplina(String idDisc) {

		Disciplina db = new Disciplina();

		ResultSet rs = null;

		String selectString = "SELECT * FROM disciplina where iddisc=?";

		try {
			PreparedStatement selDis = conn.prepareStatement(selectString);
			selDis.setString(1, idDisc);

			rs = selDis.executeQuery();

			rs.next();

			db.setIdDisc(rs.getString("idDisc"));
			db.setNomeDisc(rs.getString("nomeDisc"));
			db.setCredDisc(rs.getInt("credDisc"));
			db.setHorasDisc(rs.getInt("horasDisc"));
			db.setPeriodo(rs.getInt("periodo"));
			db.setObrigOpt(rs.getString("obrigOpt"));

		} catch (SQLException se) {
			se.printStackTrace();
		}

		return db;
	}

	public String inserirDisciplina(Disciplina disc) {

		String insertString = "insert into disciplina values(?, ?, ?, ?, ?, ?)";
	
		int result = 0;
		
		try {
			PreparedStatement cadDis = conn.prepareStatement(insertString);

			cadDis.setString(1, disc.getIdDisc());
			cadDis.setString(2, disc.getNomeDisc());
			cadDis.setInt(3, disc.getCredDisc());
			cadDis.setInt(4, disc.getHorasDisc());
			cadDis.setInt(5, disc.getPeriodo());
			cadDis.setString(6, disc.getObrigOpt());
			
			result = cadDis.executeUpdate();
			
		} catch (SQLException ex) {
			System.err.println("SQLException: " + ex.getMessage());

		}
		
		if (result==0)
			return "POST: Disciplina with id " + disc.getIdDisc() + " not inserted";
		else
			return "POST: Disciplina with id " + disc.getIdDisc() + " was inserted";

	}

	public List<Disciplina> listarDisciplinas() {

		List<Disciplina> disciplinas = new ArrayList<Disciplina>();
		Statement s = null;
		ResultSet rs = null;
		try {
			s = conn.createStatement();
			rs = s.executeQuery("SELECT * FROM disciplina");
			while (rs.next()) {
				Disciplina db = new Disciplina();
				db.setIdDisc(rs.getString("idDisc"));
				db.setNomeDisc(rs.getString("nomeDisc"));
				db.setCredDisc(rs.getInt("credDisc"));
				db.setHorasDisc(rs.getInt("horasDisc"));
				db.setPeriodo(rs.getInt("periodo"));
				db.setObrigOpt(rs.getString("obrigOpt"));
				disciplinas.add(db);
			}
		} catch (SQLException se) {
			se.printStackTrace();
		}

		return disciplinas;
	}

	public String apagaDisciplina(String idDisc) {

		String selectString = "DELETE FROM disciplina where iddisc=?";
		int result = 0;
		//System.out.println(idDisc);
		
		try {
			PreparedStatement delDis = conn.prepareStatement(selectString);
			delDis.setString(1, idDisc);
			result = delDis.executeUpdate();
		} catch (SQLException se) {
			se.printStackTrace();
		}
		
		if (result==0)
			return "DELETE: Disciplina with id " + idDisc + " not found";
		else
			return "DELETE: Disciplina with id " + idDisc + " was removed";
	}
	
	
	public List<Disciplina> listarDisciplinasMemoria() {

		List<Disciplina> disciplinas = new ArrayList<Disciplina>();
		
		Disciplina disciplina=  new Disciplina();
		disciplina.setNomeDisc("portugues");
		disciplina.setIdDisc("1");
		disciplinas.add(disciplina);
		
		

		return disciplinas;
	}
}
