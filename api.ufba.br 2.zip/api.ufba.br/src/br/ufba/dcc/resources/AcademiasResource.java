package br.ufba.dcc.resources;

import java.io.IOException;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.UriInfo;

import br.ufba.dcc.dao.AcademiaDAO;
import br.ufba.dcc.dao.DisciplinaDAO;
import br.ufba.dcc.model.Academia;
import br.ufba.dcc.model.Disciplina;

@Path("/academias")
public class AcademiasResource {

	@Context
	UriInfo uriInfo;
	@Context
	Request request;

	// Return the list of disciplinas to the user in the browser
	@GET
	@Produces(MediaType.TEXT_XML)
	public List<Academia> getAcademiasBrowser() {
		return AcademiaDAO.instance.listarAcademias();
	}

	@GET
	@Path("/json")
	@Produces({ "application/json" })
	public List<Academia> getAcademias() {
		return AcademiaDAO.instance.listarAcademias();
	}
	
//	@GET
//	@Path("/json")
//	@Produces(MediaType.TEXT_PLAIN)
//	public List<Disciplina> listarDisciplinasMemoria() {
//		return DisciplinaDAO.instance.listarDisciplinasMemoria();
//	}

//	
//	@GET
//	@Path("count")
//	@Produces(MediaType.TEXT_PLAIN)
//	public String getCount() {
//		int count = DisciplinaDAO.instance.listarDisciplinas().size();
//		return String.valueOf(count);
//	}
//
//	@GET
//	@Produces({ MediaType.APPLICATION_XML })
//	@Path("{id}.xml")
//	public Disciplina getDisciplinaXML(@PathParam("id") String id) {
//		Disciplina disciplina = DisciplinaDAO.instance.pegaDisciplina(id);
//		if (disciplina == null)
//			throw new RuntimeException("Get: Disciplina with " + id
//					+ " not found");
//		return disciplina;
//	}
//
//	@GET
//	@Produces({ MediaType.APPLICATION_JSON })
//	@Path("{id}.json")
//	public Disciplina getDisciplinaJSON(@PathParam("id") String id) {
//		Disciplina disciplina = DisciplinaDAO.instance.pegaDisciplina(id);
//		if (disciplina == null)
//			throw new RuntimeException("Get: Disciplina with " + id
//					+ " not found");
//		return disciplina;
//	}
//
//	@POST
//	@Produces(MediaType.TEXT_PLAIN)
//	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
//	public String novaDisciplina(@FormParam("codDisc") String codDisc,
//			@FormParam("nomeDisc") String nomeDisc,
//			@FormParam("credDisc") String credDisc,
//			@FormParam("horDisc") String horDisc,
//			@FormParam("perDisc") String perDisc,
//			@FormParam("tipoDisc") String tipoDisc) throws IOException {
//
//		Disciplina disc = new Disciplina();
//
//		if (codDisc != null) {
//			disc.setIdDisc(codDisc);
//			disc.setNomeDisc(nomeDisc);
//			disc.setObrigOpt(tipoDisc);
//			disc.setCredDisc(Integer.parseInt(credDisc));
//			disc.setHorasDisc(Integer.parseInt(horDisc));
//			disc.setPeriodo(Integer.parseInt(perDisc));
//
//		}
//
//		return DisciplinaDAO.instance.inserirDisciplina(disc);
//
//	}
//
//	@DELETE
//	@Produces(MediaType.TEXT_PLAIN)
//	public String deleteDisciplina(
//			@DefaultValue("MATC") @QueryParam("codDisc") String codDisc)
//			throws IOException {
//
//		if (codDisc == null)
//			throw new RuntimeException("Delete: Disciplina with " + codDisc
//					+ " not found");
//
//		// System.out.println(codDisc);
//
//		return DisciplinaDAO.instance.apagaDisciplina(codDisc);
//	}

}
