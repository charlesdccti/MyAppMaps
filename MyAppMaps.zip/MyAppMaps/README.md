# Navegação das telas e obtenção dos dados de sensores 
DISCIPLINA: MATC89 - Aplicações para Dispositivos Móveis
